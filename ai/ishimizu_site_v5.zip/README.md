
# Ishimizu website (final build with brand palette)

This is a static site ready to deploy with the **Ishimizu color chart** wired in (Terre cuite #4f3724, Bleu ardoise #8f97a8, Vert sauge #98a08c, Ivoire #fbf9f5, Rose pêche #e6cab7).

## How to use your existing images
1. Option A — manual: place images under `assets/images/` and edit `assets/data/images.json`.
2. Option B — auto: run the helper scripts from the `tools/` folder:

```bash
python3 tools/fetch_synology_share.py "http://gofile.me/48bzK/qwWWDSuNq" -o ./_incoming
python3 tools/wire_assets_and_build.py
```

The second script will sort files into `assets/images/...`, generate `assets/data/images.json` that matches your exact filenames, and produce `dist/ishimizu_site_ready.zip` for deployment at **ishimizu.be**.

## Pages
- `index.html` (Home + carousel)
- `models.html` (3 models with product variants)
- `stones.html` (stones & symbolism; belief-based language, no health claims)
- `story.html` (brand story & contact)

## SEO & PWA
- Open Graph meta ready. Replace `og-cover.jpg` path when you add it.
- `sitemap.xml`, `robots.txt`, and `site.webmanifest` included; theme-color set to Vert sauge.

## Brand typeface
- Poppins is loaded via Google Fonts in the `<head>` of every page.

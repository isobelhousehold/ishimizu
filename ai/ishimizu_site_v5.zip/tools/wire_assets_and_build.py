#!/usr/bin/env python3
import os, re, json, zipfile, shutil
from pathlib import Path
SITE = Path(__file__).resolve().parents[1]
INCOMING = SITE / "_incoming"
ASSETS = SITE / "assets" / "images"
OUT = SITE / "dist"
OUT.mkdir(exist_ok=True)
ASSETS.mkdir(parents=True, exist_ok=True)
(ASSETS/"hero").mkdir(parents=True, exist_ok=True)
(ASSETS/"models").mkdir(parents=True, exist_ok=True)
(ASSETS/"products").mkdir(parents=True, exist_ok=True)
(ASSETS/"stones").mkdir(parents=True, exist_ok=True)
PRODUCTS = json.loads((SITE/"assets/data/products.json").read_text())
STONE_NAMES = sorted({p["Stones_Name"] for p in PRODUCTS})
REFS = {p["Référence"] for p in PRODUCTS}

def copy(src: Path, dest: Path):
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)

images = [p for p in INCOMING.rglob("*") if p.is_file() and p.suffix.lower() in (".jpg",".jpeg",".png",".webp",".svg",".ico")]
logo = next((p for p in images if "logo" in p.stem.lower() or "ishimizu" in p.stem.lower()), None)
if logo:
    copy(logo, SITE/"assets/images/logo.svg" if logo.suffix.lower()==".svg" else SITE/"assets/images/logo"+logo.suffix.lower())
favicons = [p for p in images if p.name.lower() in ("favicon.ico","favicon-16x16.png","favicon-32x32.png","apple-touch-icon.png","android-chrome-192x192.png","android-chrome-512x512.png")]
for f in favicons:
    copy(f, SITE/f.name)
hero_candidates = sorted(images, key=lambda p:(("life" in p.stem.lower() or "hero" in p.stem.lower()), p.stat().st_size), reverse=True)
hero = hero_candidates[:3]
for i, h in enumerate(hero, 1):
    copy(h, ASSETS/"hero"/f"hero-{i}{h.suffix.lower()}")
for m in ("heiwa","kanjo","hogo"):
    cand = next((p for p in images if m in p.stem.lower()), None)
    if cand: copy(cand, ASSETS/"models"/f"{m}{cand.suffix.lower()}")
for s in STONE_NAMES:
    slug = s.lower().replace(" ","-")
    cand = next((p for p in images if s.replace(" ","").lower() in p.stem.replace(" ","").lower()), None)
    if cand: copy(cand, ASSETS/"stones"/f"{slug}{cand.suffix.lower()}")
for ref in REFS:
    cand = next((p for p in images if ref.lower() in p.name.lower()), None)
    if cand: copy(cand, ASSETS/"products"/cand.name)
manifest = {"logo": None, "hero": [], "models": {"heiwa": None, "kanjo": None, "hogo": None}, "stones": {}, "products": {}}
for p in (SITE/"assets/images").glob("logo.*"):
    manifest["logo"] = "/assets/images/"+p.name
for p in sorted((ASSETS/"hero").glob("hero-*")):
    manifest["hero"].append("/assets/images/hero/"+p.name)
for m in ("heiwa","kanjo","hogo"):
    mp = next((p for p in (ASSETS/"models").glob(m+"*")), None)
    if mp: manifest["models"][m] = "/assets/images/models/"+mp.name
for s in STONE_NAMES:
    slug = s.lower().replace(" ","-")
    mp = next((p for p in (ASSETS/"stones").glob(slug+"*")), None)
    if mp: manifest["stones"][s] = "/assets/images/stones/"+mp.name
for ref in REFS:
    mp = next((p for p in (ASSETS/"products").glob(f"*{ref}*")), None)
    if mp: manifest["products"][ref] = "/assets/images/products/"+mp.name
(SITE/"assets/data/images.json").write_text(json.dumps(manifest, indent=2))
print("images.json created")
zip_path = OUT/"ishimizu_site_ready.zip"
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for dirpath, _, filenames in os.walk(SITE):
        if any(part in dirpath for part in ("__pycache__", ".venv", "dist", "_incoming", "tools")):
            continue
        for f in filenames:
            p = Path(dirpath)/f
            z.write(p, arcname=str(p.relative_to(SITE)))
print("Built:", zip_path)

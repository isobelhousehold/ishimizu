#!/usr/bin/env python3
import argparse, os, re, sys, urllib.parse, pathlib, requests
from bs4 import BeautifulSoup
ALLOWED = {".jpg",".jpeg",".png",".webp",".svg",".ico"}
SEEN = set()

def is_file_link(href: str) -> bool:
    if not href: return False
    p = urllib.parse.urlparse(href)
    return any(p.path.lower().endswith(ext) for ext in ALLOWED)

def absolutize(base, href):
    return urllib.parse.urljoin(base, href)

def fetch(url, session):
    r = session.get(url, allow_redirects=True, timeout=30)
    r.raise_for_status()
    return r.text

def crawl(start_url, out_dir):
    session = requests.Session()
    queue = [start_url]
    files = []
    while queue:
        url = queue.pop(0)
        if url in SEEN: continue
        SEEN.add(url)
        try:
            html = fetch(url, session)
        except Exception as e:
            print("Skip:", url, e); continue
        soup = BeautifulSoup(html, "html.parser")
        for a in soup.find_all("a", href=True):
            href = absolutize(url, a["href"])
            if is_file_link(href):
                files.append(href)
            else:
                if "gofile.me" in href or "synology.com" in href:
                    if href not in SEEN: queue.append(href)
    os.makedirs(out_dir, exist_ok=True)
    for idx, f in enumerate(sorted(set(files))):
        try:
            r = session.get(f, stream=True, timeout=60)
            r.raise_for_status()
            name = pathlib.Path(urllib.parse.unquote(urllib.parse.urlparse(f).path)).name
            dest = pathlib.Path(out_dir) / name
            with open(dest, "wb") as w:
                for chunk in r.iter_content(1024*128):
                    w.write(chunk)
            print(f"[{idx+1}/{len(files)}] downloaded {name}")
        except Exception as e:
            print("Failed:", f, e)
    return out_dir

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("url", help="gofile.me share URL")
    ap.add_argument("-o", "--out", default="../_incoming", help="output folder")
    args = ap.parse_args()
    out = crawl(args.url, args.out)
    print("Assets saved to:", out)

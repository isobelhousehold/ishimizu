Place your logo files here:
- logo_ishimizu_beige.png (light beige on dark background)
- logo_ishimizu_beige.svg
- logo_Ishimizu_brun.png (dark brown on light background)
- logo_ishimizu_brun.svg
Header logo ~56px tall; Footer logo ~44px.

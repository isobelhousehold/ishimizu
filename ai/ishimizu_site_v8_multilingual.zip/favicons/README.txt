Place favicon files here:
- android-chrome-192x192.png
- android-chrome-512x512.png
- apple-touch-icon.png
- favicon-16.png
- favicon-32.png
- favicon-48.png
- favicon.ico
